
About licence

1. Form index.html without cryptography is under open source licence at website https://uicookies.com/html-form-design-examples/
2. md5.js is under MIT open source licence

About index.html (email with cryptography)

There are some validations on input fields. When you fill message field and click anywhere on the form hash is to be calculated.

Conclusion

I don't have email server (i am retired). I don't know am i on right way with my application. Please send me your opinion if you think that the
application can be improved. 

Best regards. 